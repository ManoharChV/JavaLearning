﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankLibrary;

namespace BankApp
{
    class Program
    {
        static void Main(string[] args)
        {
            #region BankObject
            //Bank b = new Bank();
            //b.Name = "manohar";
            ////b.Balance = 10000;
            //Console.WriteLine(b);
            //b.Deposit(6000);
            //Console.WriteLine("After Deposit balance="+b.Balance);
            //b.WithDraw(4000);
            //Console.WriteLine("After withdraw balance=" + b.Balance);
            //Console.ReadLine();
            //Bank b = new Bank("manohar", 20000);
            //Console.WriteLine(b);
            //Bank b1 = new Bank();
            //Bank b2 = new Bank();
            //Console.WriteLine(Bank.Count);
            //Console.ReadLine();
            #endregion
            Savings s1 = new Savings();
            //s.Deposit(1000);
            Savings s2 = new Savings("manohar", 20000);
            Console.WriteLine(s2);
            try
            {
                s2.WithDraw(30000);
            }
            catch(BalanceException e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine("no of accounts created="+Savings.Count); 
            Console.ReadLine();

        }
    }
}
