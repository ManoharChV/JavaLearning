﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
   public  class Savings : Bank
    {
        public Savings()
        {

        }
        public Savings(string name,double amt) : base(name, amt)
        {

        }
        public override void WithDraw(double amt)
        {
            if (Balance - amt >= 1000)
            {
                Balance -= amt;
            }
            else
            {
                throw new BalanceException("not enough balance");
            }
        }
    }
}
