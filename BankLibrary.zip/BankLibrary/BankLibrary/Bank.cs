﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankLibrary
{
    public class Bank
    {
        #region fields&properties
        string name;
        double balance;
        private static int count = 0;
        public string Name{
            get { return name; }
            set { name = value; }
             }
        public double Balance
        {
            get { return balance; }
           protected set { balance = value; }
        }
        public static int Count
        {
            set { count = value; }
            get { return count; }
        }
        #endregion



        #region methods
        public void Deposit(double amt)
        {
            balance = balance + amt;

        }
        virtual public void WithDraw(double amt)
        {
            balance = balance - amt;
        }
        public override string ToString()
        {
            return string.Format("AccountHolderName = {0}  Balance = {1}",Name, Balance);
        }
        #endregion

        #region Constructor
        public Bank()
        {
            count++;
            Balance = 1000;
        }
        public Bank(string name,double bal):this()
        {
            this.Name = name;
            this.Balance = bal;
        }
        #endregion


    }
}
